import React from 'react';
import { 
  Clock, 
  Calendar, 
  Repeat, 
  Volume2, 
  Vibrate, 
  Edit3, 
  Trash2, 
  Check, 
  Bell, 
  BellOff, 
  RotateCcw,
  Sparkles
} from 'lucide-react';
import { Reminder } from '../types';
import { reminderEngine } from '../services/reminderEngine';

interface ReminderCardProps {
  reminder: Reminder;
  onToggle: (id: string) => void;
  onEdit: (reminder: Reminder) => void;
  onDelete: (reminder: Reminder) => void;
  onComplete?: (id: string) => void;
  onRestore?: (id: string) => void;
  onTriggerNow?: (reminder: Reminder) => void;
  use24h?: boolean;
}

export const ReminderCard: React.FC<ReminderCardProps> = ({
  reminder,
  onToggle,
  onEdit,
  onDelete,
  onComplete,
  onRestore,
  onTriggerNow,
  use24h = false,
}) => {
  const formattedTime = reminderEngine.formatDisplayTime(reminder.time, use24h);
  const formattedDate = reminderEngine.formatDisplayDate(reminder.date);

  const getTaskEmoji = (title: string) => {
    const lower = title.toLowerCase();
    if (lower.includes('gym') || lower.includes('workout') || lower.includes('exercise')) return '🏋️';
    if (lower.includes('shop') || lower.includes('market') || lower.includes('grocery')) return '🛒';
    if (lower.includes('padhai') || lower.includes('study') || lower.includes('book')) return '📚';
    if (lower.includes('medicine') || lower.includes('dawa') || lower.includes('pill')) return '💊';
    if (lower.includes('call') || lower.includes('papa') || lower.includes('mummy')) return '📞';
    if (lower.includes('water') || lower.includes('drink')) return '💧';
    if (lower.includes('meeting') || lower.includes('work')) return '💼';
    return '⏰';
  };

  const getRepeatLabel = (repeat: string) => {
    switch (repeat) {
      case 'daily':
        return 'Every Day';
      case 'weekly':
        return 'Every Week';
      case 'once':
        return 'Once';
      default:
        return repeat.charAt(0).toUpperCase() + repeat.slice(1);
    }
  };

  const isCompleted = reminder.completed;

  return (
    <div
      className={`group relative rounded-2xl border transition-all ${
        isCompleted
          ? 'bg-slate-900/40 border-slate-800/60 opacity-60'
          : reminder.enabled
          ? 'bg-slate-800/50 border-slate-700/50 hover:border-indigo-500/40 hover:bg-slate-800/80 shadow-sm'
          : 'bg-slate-900/40 border-slate-800/80 opacity-60'
      } p-4`}
    >
      <div className="flex items-center justify-between gap-3">
        {/* Left Side: Emoji + Details */}
        <div className="flex items-center gap-3.5 min-w-0 flex-1">
          {/* Quick Complete / Restore button */}
          {isCompleted ? (
            <button
              onClick={() => onRestore && onRestore(reminder.id)}
              className="shrink-0 w-8 h-8 rounded-xl bg-indigo-950/60 border border-indigo-800/50 text-indigo-400 flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
              title="Restore / Re-activate task"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={() => onComplete && onComplete(reminder.id)}
              className="shrink-0 w-8 h-8 rounded-xl border border-slate-700 hover:border-indigo-500 hover:bg-indigo-950/30 text-transparent hover:text-indigo-400 flex items-center justify-center transition-all"
              title="Mark as completed"
            >
              <Check className="w-4 h-4" />
            </button>
          )}

          {/* Time Badge */}
          <div className="shrink-0 text-indigo-400 font-bold text-sm font-mono tracking-tight">
            {formattedTime}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-sm">{getTaskEmoji(reminder.title)}</span>
              <h4
                className={`text-sm font-semibold truncate ${
                  isCompleted
                    ? 'line-through text-slate-500'
                    : 'text-slate-100'
                }`}
              >
                {reminder.title}
              </h4>
              {reminder.isSnoozed && (
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Snoozed ({reminder.snoozeMinutes}m)
                </span>
              )}
            </div>

            {reminder.description && (
              <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                {reminder.description}
              </p>
            )}

            {/* Repeat and Subtitle info */}
            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5 mt-1 text-[10px] text-slate-400">
              <span className="font-medium text-slate-300">
                {getRepeatLabel(reminder.repeat)}
              </span>
              <span>•</span>
              <span className="capitalize">{reminder.sound}</span>
              {reminder.vibration && (
                <>
                  <span>•</span>
                  <span>Vibration ON</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Toggle Switch & Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          {!isCompleted && (
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={reminder.enabled}
                onChange={() => onToggle(reminder.id)}
                className="sr-only peer"
              />
              <div className="w-10 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          )}

          {/* Action buttons */}
          <div className="flex items-center gap-0.5">
            {onTriggerNow && !isCompleted && reminder.enabled && (
              <button
                onClick={() => onTriggerNow(reminder)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-400 hover:bg-slate-800 transition-colors"
                title="Test trigger alarm now"
              >
                <Bell className="w-3.5 h-3.5" />
              </button>
            )}

            <button
              onClick={() => onEdit(reminder)}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-200 hover:bg-slate-800 transition-colors"
              title="Edit Reminder"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => onDelete(reminder)}
              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
              title="Delete Reminder"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
