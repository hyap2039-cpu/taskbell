import React, { useState, useEffect } from 'react';
import { Bell, Clock, Repeat, Volume2, Sparkles, AlertCircle, ArrowRight } from 'lucide-react';
import { Reminder } from '../types';
import { reminderEngine } from '../services/reminderEngine';

interface NextReminderCardProps {
  nextData: { reminder: Reminder; triggerDate: Date } | null;
  onOpenAddModal: () => void;
  onEditReminder: (reminder: Reminder) => void;
  onTriggerNow: (reminder: Reminder) => void;
  use24h?: boolean;
}

export const NextReminderCard: React.FC<NextReminderCardProps> = ({
  nextData,
  onOpenAddModal,
  onEditReminder,
  onTriggerNow,
  use24h = false,
}) => {
  const [countdownText, setCountdownText] = useState<string>('');

  useEffect(() => {
    if (!nextData) return;

    const updateCountdown = () => {
      const now = Date.now();
      const diffMs = nextData.triggerDate.getTime() - now;

      if (diffMs <= 0) {
        setCountdownText('Due right now');
        return;
      }

      const totalSec = Math.floor(diffMs / 1000);
      const hours = Math.floor(totalSec / 3600);
      const minutes = Math.floor((totalSec % 3600) / 60);
      const seconds = totalSec % 60;

      if (hours > 24) {
        const days = Math.floor(hours / 24);
        setCountdownText(`In ${days} day${days > 1 ? 's' : ''}`);
      } else if (hours > 0) {
        setCountdownText(`In ${hours}h ${minutes}m`);
      } else if (minutes > 0) {
        setCountdownText(`In ${minutes}m ${seconds}s`);
      } else {
        setCountdownText(`In ${seconds}s`);
      }
    };

    updateCountdown();
    const timer = setInterval(updateCountdown, 1000);
    return () => clearInterval(timer);
  }, [nextData]);

  if (!nextData) {
    return (
      <div className="relative overflow-hidden rounded-3xl bg-slate-900 border border-slate-800 p-6 text-center shadow-lg">
        <div className="w-12 h-12 mx-auto rounded-2xl bg-indigo-950/60 border border-indigo-800/40 flex items-center justify-center text-indigo-400 mb-3">
          <Sparkles className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-white mb-1">
          No Active Reminders
        </h3>
        <p className="text-xs text-slate-400 max-w-xs mx-auto mb-4">
          You are all caught up! Create a custom reminder with an alarm sound and schedule.
        </p>
        <button
          onClick={onOpenAddModal}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-900/40 active:scale-95 transition-all"
        >
          <Bell className="w-3.5 h-3.5" />
          Schedule a Reminder
        </button>
      </div>
    );
  }

  const { reminder, triggerDate } = nextData;
  const formattedTime = reminderEngine.formatDisplayTime(reminder.time, use24h);
  const formattedDate = reminderEngine.formatDisplayDate(reminder.date);

  // Helper emoji selector
  const getTaskEmoji = (title: string) => {
    const lower = title.toLowerCase();
    if (lower.includes('gym') || lower.includes('workout') || lower.includes('exercise')) return '🏋️';
    if (lower.includes('shop') || lower.includes('market') || lower.includes('grocery')) return '🛒';
    if (lower.includes('padhai') || lower.includes('study') || lower.includes('book')) return '📚';
    if (lower.includes('medicine') || lower.includes('dawa') || lower.includes('pill')) return '💊';
    if (lower.includes('call') || lower.includes('papa') || lower.includes('mummy')) return '📞';
    if (lower.includes('water') || lower.includes('drink')) return '💧';
    if (lower.includes('meeting') || lower.includes('work')) return '💼';
    return '⏰';
  };

  return (
    <div className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-3xl p-5 sm:p-6 shadow-xl shadow-indigo-950/50 mb-4 relative overflow-hidden text-white">
      {/* Decorative ambient blur circle */}
      <div className="absolute -right-4 -top-4 w-28 h-28 bg-white/15 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -bottom-6 -left-6 w-28 h-28 bg-indigo-400/20 rounded-full blur-xl pointer-events-none" />

      {/* Header Eyebrow & Countdown */}
      <div className="flex items-center justify-between mb-2 relative z-10">
        <p className="text-indigo-100 text-[10px] sm:text-xs font-bold uppercase tracking-widest flex items-center gap-1.5">
          <Bell className="w-3 h-3 text-indigo-200 animate-bell-ring" />
          <span>Next Reminder</span>
        </p>
        <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-black/25 text-xs font-mono font-medium text-indigo-100 backdrop-blur-xs">
          <Clock className="w-3 h-3 text-indigo-200" />
          <span>{countdownText}</span>
        </div>
      </div>

      {/* Big Bold Time */}
      <div className="mb-1 relative z-10">
        <div className="text-3xl sm:text-4xl font-extrabold tracking-tight font-sans text-white flex items-baseline gap-2">
          {formattedTime}
          <span className="text-xs font-sans font-medium text-indigo-100/80 bg-white/10 px-2 py-0.5 rounded-md">
            {formattedDate}
          </span>
        </div>
      </div>

      {/* Task Name */}
      <div className="mb-4 relative z-10">
        <h4 className="text-base sm:text-lg font-semibold text-white flex items-center gap-2">
          <span>{getTaskEmoji(reminder.title)}</span>
          <span className="truncate">{reminder.title}</span>
        </h4>
        {reminder.description && (
          <p className="text-xs text-indigo-100/80 mt-0.5 line-clamp-1">
            {reminder.description}
          </p>
        )}
      </div>

      {/* Metadata Badges & Quick Action */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 pt-3 border-t border-white/15 relative z-10">
        <div className="flex items-center gap-1.5 text-xs text-indigo-100">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/10 text-[11px] capitalize">
            <Repeat className="w-3 h-3" />
            {reminder.repeat}
          </span>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/10 text-[11px] capitalize">
            <Volume2 className="w-3 h-3" />
            {reminder.sound}
          </span>
          {reminder.isSnoozed && (
            <span className="px-2 py-0.5 rounded-md bg-amber-400/30 text-amber-200 text-[11px] font-bold">
              Snoozed ({reminder.snoozeMinutes}m)
            </span>
          )}
        </div>

        {/* Quick Test Trigger / Edit */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onTriggerNow(reminder)}
            className="px-3 py-1 rounded-xl bg-white/20 hover:bg-white/30 active:scale-95 text-xs font-bold text-white transition-all flex items-center gap-1 shadow-sm"
            title="Trigger alarm test right now"
          >
            <span>Test Alarm</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
