import React from 'react';
import { Trash2, AlertTriangle, X } from 'lucide-react';
import { Reminder } from '../types';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  reminder: Reminder | null;
  onConfirm: () => void;
  onCancel: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  reminder,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen || !reminder) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 p-6 text-slate-100">
        <div className="w-12 h-12 rounded-2xl bg-rose-950/60 border border-rose-900/50 text-rose-400 flex items-center justify-center mx-auto mb-4">
          <Trash2 className="w-6 h-6" />
        </div>

        <h3 className="text-base font-bold text-center text-white mb-2">
          Delete Reminder?
        </h3>

        <p className="text-xs text-center text-slate-400 mb-5 leading-relaxed">
          Are you sure you want to delete <span className="font-semibold text-slate-200">"{reminder.title}"</span>? This action cannot be undone.
        </p>

        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="flex-1 py-3 px-4 rounded-xl border border-slate-700 text-slate-300 font-semibold text-xs hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-950/50 active:scale-95 transition-all"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};
