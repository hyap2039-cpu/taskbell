import React from 'react';
import { Bell, Moon, Sun, Monitor, Download, Smartphone } from 'lucide-react';
import { AppSettings } from '../types';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  currentTime: Date;
  activeCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onUpdateSettings,
  currentTime,
  activeCount,
}) => {
  const { isInstallable, install, isIOS } = usePWAInstall();

  const cycleTheme = () => {
    const nextTheme = settings.theme === 'light' ? 'dark' : settings.theme === 'dark' ? 'system' : 'light';
    onUpdateSettings({ theme: nextTheme });
  };

  const formattedTime = currentTime.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: !settings.twentyFourHourFormat,
  });

  const formattedDate = currentTime.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <header className="sticky top-0 z-30 w-full bg-slate-900/95 backdrop-blur-md border-b border-slate-800 transition-colors">
      <div className="max-w-3xl mx-auto px-5 py-3.5 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-lg shadow-indigo-950/40">
            <Bell className="w-5 h-5 animate-pulse" />
            {activeCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-500 text-white rounded-full text-[10px] font-black flex items-center justify-center ring-2 ring-slate-900">
                {activeCount > 9 ? '9+' : activeCount}
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black tracking-tight text-indigo-400">
                TaskBell
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-950/70 border border-indigo-800/50 text-indigo-300">
                Mobile
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              {formattedDate}
            </p>
          </div>
        </div>

        {/* Live Clock & Quick Controls */}
        <div className="flex items-center gap-2.5">
          {/* Live digital clock pill */}
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-slate-700/60 font-mono text-xs font-semibold text-slate-300">
            <span>{formattedTime}</span>
          </div>

          {/* In-app Install Button if PWA prompt ready */}
          {isInstallable && (
            <button
              onClick={install}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-indigo-600 text-white shadow-sm hover:bg-indigo-500 active:scale-95 transition-all"
              title="Install TaskBell as Mobile App"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">Install</span>
            </button>
          )}

          {/* Theme Toggle Button */}
          <button
            onClick={cycleTheme}
            className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700/60 flex items-center justify-center text-slate-400 hover:text-indigo-400 hover:border-indigo-500/40 transition-all"
            title={`Theme: ${settings.theme} (click to change)`}
          >
            {settings.theme === 'light' ? (
              <Sun className="w-4.5 h-4.5 text-amber-400" />
            ) : settings.theme === 'dark' ? (
              <Moon className="w-4.5 h-4.5 text-indigo-400" />
            ) : (
              <Monitor className="w-4.5 h-4.5 text-slate-400" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
