import React, { useState, useEffect } from 'react';
import { 
  X, 
  Clock, 
  Calendar, 
  Repeat, 
  Volume2, 
  Vibrate, 
  Bell, 
  Play, 
  Square, 
  Sparkles,
  AlertTriangle,
  Check
} from 'lucide-react';
import { Reminder, RepeatType, AlarmSoundId, AppSettings } from '../types';
import { soundService } from '../services/soundService';

interface AddEditReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (reminder: Reminder) => void;
  initialReminder?: Reminder | null;
  settings: AppSettings;
}

const QUICK_SUGGESTIONS = [
  { label: 'Gym jaana hai', emoji: '🏋️' },
  { label: 'Papa ko call karna hai', emoji: '📞' },
  { label: 'Shop jaana hai', emoji: '🛒' },
  { label: 'Padhai karni hai', emoji: '📚' },
  { label: 'Medicine lena hai', emoji: '💊' },
];

export const AddEditReminderModal: React.FC<AddEditReminderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialReminder,
  settings,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [repeat, setRepeat] = useState<RepeatType>('daily');
  const [sound, setSound] = useState<AlarmSoundId>(settings.defaultSound || 'classic');
  const [vibration, setVibration] = useState<boolean>(settings.defaultVibration ?? true);
  const [notification, setNotification] = useState<boolean>(settings.defaultNotification ?? true);
  
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isPreviewingSound, setIsPreviewingSound] = useState(false);

  // Helper to format Date to YYYY-MM-DD
  const formatDateToInput = (d: Date): string => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  // Helper to format time to HH:mm
  const formatTimeToInput = (d: Date): string => {
    const h = String(d.getHours()).padStart(2, '0');
    const m = String(d.getMinutes()).padStart(2, '0');
    return `${h}:${m}`;
  };

  useEffect(() => {
    if (!isOpen) {
      soundService.stop();
      setIsPreviewingSound(false);
      return;
    }

    if (initialReminder) {
      setTitle(initialReminder.title);
      setDescription(initialReminder.description || '');
      setDate(initialReminder.date);
      setTime(initialReminder.time);
      setRepeat(initialReminder.repeat);
      setSound(initialReminder.sound);
      setVibration(initialReminder.vibration);
      setNotification(initialReminder.notification);
    } else {
      // Default new reminder: 5 minutes from now
      const defaultDate = new Date(Date.now() + 5 * 60 * 1000);
      setTitle('');
      setDescription('');
      setDate(formatDateToInput(defaultDate));
      setTime(formatTimeToInput(defaultDate));
      setRepeat('once');
      setSound(settings.defaultSound || 'classic');
      setVibration(settings.defaultVibration ?? true);
      setNotification(settings.defaultNotification ?? true);
    }
    setErrorMsg(null);
  }, [isOpen, initialReminder, settings]);

  if (!isOpen) return null;

  const handlePlaySoundPreview = () => {
    if (isPreviewingSound) {
      soundService.stop();
      setIsPreviewingSound(false);
    } else {
      setIsPreviewingSound(true);
      soundService.playSinglePattern(sound);
      setTimeout(() => {
        setIsPreviewingSound(false);
      }, 1500);
    }
  };

  const handleQuickAddMinutes = (min: number) => {
    const target = new Date(Date.now() + min * 60 * 1000);
    setDate(formatDateToInput(target));
    setTime(formatTimeToInput(target));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Please enter a task name.');
      return;
    }
    if (!date) {
      setErrorMsg('Please select a date.');
      return;
    }
    if (!time) {
      setErrorMsg('Please select a time.');
      return;
    }

    // Check if once-only task is scheduled in the past
    if (repeat === 'once') {
      const scheduledDateTime = new Date(`${date}T${time}:00`);
      if (scheduledDateTime.getTime() < Date.now() - 60000) {
        setErrorMsg('The selected date and time is in the past. Choose an upcoming time.');
        return;
      }
    }

    const reminderData: Reminder = {
      id: initialReminder ? initialReminder.id : `task-${Date.now()}`,
      title: title.trim(),
      description: description.trim() || undefined,
      date,
      time,
      repeat,
      sound,
      vibration,
      notification,
      enabled: true,
      completed: false,
      createdAt: initialReminder ? initialReminder.createdAt : new Date().toISOString(),
    };

    onSave(reminderData);
    onClose();
  };

  const repeatOptions: { value: RepeatType; label: string }[] = [
    { value: 'once', label: 'Once' },
    { value: 'daily', label: 'Daily (Everyday)' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monday', label: 'Every Monday' },
    { value: 'tuesday', label: 'Every Tuesday' },
    { value: 'wednesday', label: 'Every Wednesday' },
    { value: 'thursday', label: 'Every Thursday' },
    { value: 'friday', label: 'Every Friday' },
    { value: 'saturday', label: 'Every Saturday' },
    { value: 'sunday', label: 'Every Sunday' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/80 backdrop-blur-sm p-0 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="w-full max-w-lg bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-800 max-h-[92vh] flex flex-col overflow-hidden text-slate-100">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-950/60 border border-indigo-800/40 text-indigo-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {initialReminder ? 'Edit Reminder' : 'New Smart Alarm'}
              </h3>
              <p className="text-xs text-slate-400">
                Configure time, repeat schedule, and sound
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-900/60 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Task Name */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Task Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Gym jaana hai"
              className="w-full px-4 py-3 rounded-2xl bg-slate-800 border border-slate-700 text-white text-base font-medium placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
              required
              autoFocus
            />

            {/* Quick Suggestion Chips */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {QUICK_SUGGESTIONS.map((item) => (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => setTitle(item.label)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-indigo-950/60 hover:text-indigo-300 border border-slate-700/60 transition-colors"
                >
                  <span>{item.emoji}</span>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Description (optional) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Description / Notes (Optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add details, instructions, or subtasks..."
              rows={2}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-800 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all resize-none"
            />
          </div>

          {/* Date & Time Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                <span>Date</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                <span>Time</span>
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm font-medium font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
          </div>

          {/* Quick Preset Buttons */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span>Quick Time Set:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickAddMinutes(1)}
                className="px-2.5 py-1 rounded-lg bg-indigo-950/60 border border-indigo-800/50 text-indigo-300 text-xs font-semibold hover:bg-indigo-900/50 transition-colors"
                title="Trigger alarm in 1 minute (great for testing)"
              >
                +1 min (Test)
              </button>
              <button
                type="button"
                onClick={() => handleQuickAddMinutes(5)}
                className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 text-xs font-semibold hover:bg-slate-700 transition-colors"
              >
                +5 min
              </button>
              <button
                type="button"
                onClick={() => handleQuickAddMinutes(15)}
                className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 text-xs font-semibold hover:bg-slate-700 transition-colors"
              >
                +15 min
              </button>
              <button
                type="button"
                onClick={() => handleQuickAddMinutes(60)}
                className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 text-xs font-semibold hover:bg-slate-700 transition-colors"
              >
                +1 hour
              </button>
            </div>
          </div>

          {/* Repeat Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1">
              <Repeat className="w-3.5 h-3.5 text-indigo-400" />
              <span>Repeat Schedule</span>
            </label>
            <select
              value={repeat}
              onChange={(e) => setRepeat(e.target.value as RepeatType)}
              className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {repeatOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {/* Alarm Sound Selector + Preview Button */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>Alarm Sound</span>
              </label>
              <button
                type="button"
                onClick={handlePlaySoundPreview}
                className="text-xs font-semibold text-indigo-400 hover:underline flex items-center gap-1"
              >
                {isPreviewingSound ? (
                  <>
                    <Square className="w-3 h-3 fill-current" />
                    <span>Stop Preview</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3 h-3 fill-current" />
                    <span>Test Sound</span>
                  </>
                )}
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'classic', name: 'Classic Alarm', desc: 'Twin bell hammer' },
                { id: 'digital', name: 'Digital Alarm', desc: 'Clock triple beeps' },
                { id: 'gentle', name: 'Gentle Alarm', desc: 'Harmonic chime' },
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => {
                    setSound(s.id as AlarmSoundId);
                    soundService.playSinglePattern(s.id as AlarmSoundId);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    sound === s.id
                      ? 'bg-indigo-950/60 border-indigo-500 text-indigo-100 ring-2 ring-indigo-500/30'
                      : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <div className="text-xs font-bold">{s.name}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{s.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Vibration and Notification Toggles */}
          <div className="space-y-3 pt-1 border-t border-slate-800">
            {/* Vibration Toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Vibrate className="w-4 h-4 text-slate-400" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">
                    Vibration Alert
                  </div>
                  <div className="text-[10px] text-slate-400">Rhythmic motor pulses on trigger</div>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={vibration}
                  onChange={(e) => setVibration(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-10 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>

            {/* Notification Toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-slate-400" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">
                    Browser Notification
                  </div>
                  <div className="text-[10px] text-slate-400">Display popup notification</div>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notification}
                  onChange={(e) => setNotification(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-10 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-xl border border-slate-700 text-slate-300 font-semibold text-sm hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-md shadow-indigo-900/50 active:scale-95 transition-all"
            >
              Save Reminder
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
