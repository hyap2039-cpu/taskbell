import React from 'react';
import { Home, ListTodo, Plus, CheckCircle2, Settings } from 'lucide-react';
import { NavigationTab } from '../types';

interface BottomNavigationProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onOpenAddModal: () => void;
  activeCount: number;
  completedCount: number;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  currentTab,
  onSelectTab,
  onOpenAddModal,
  activeCount,
  completedCount,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 pb-safe pt-1 transition-colors">
      <div className="max-w-md mx-auto px-4 h-20 flex items-center justify-around relative">
        {/* Home Tab */}
        <button
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentTab === 'home'
              ? 'text-indigo-400 font-bold'
              : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          {currentTab === 'home' ? (
            <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full mb-1" />
          ) : (
            <div className="w-1.5 h-1.5 bg-transparent rounded-full mb-1" />
          )}
          <Home className={`w-5 h-5 mb-0.5 ${currentTab === 'home' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] font-bold tracking-tight">Home</span>
        </button>

        {/* Reminders List Tab */}
        <button
          onClick={() => onSelectTab('reminders')}
          className={`flex flex-col items-center justify-center flex-1 py-1 relative transition-colors ${
            currentTab === 'reminders'
              ? 'text-indigo-400 font-bold'
              : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          {currentTab === 'reminders' ? (
            <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full mb-1" />
          ) : (
            <div className="w-1.5 h-1.5 bg-transparent rounded-full mb-1" />
          )}
          <div className="relative">
            <ListTodo className={`w-5 h-5 mb-0.5 ${currentTab === 'reminders' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            {activeCount > 0 && (
              <span className="absolute -top-1 -right-2 px-1 min-w-3.5 h-3.5 bg-indigo-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center shadow-sm">
                {activeCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold tracking-tight">Reminders</span>
        </button>

        {/* Floating Center '+' Add Button */}
        <div className="flex-1 flex justify-center -mt-8">
          <button
            onClick={onOpenAddModal}
            className="bg-indigo-600 hover:bg-indigo-500 active:scale-95 w-14 h-14 rounded-2xl shadow-xl shadow-indigo-900/50 flex items-center justify-center text-white transition-all"
            aria-label="Add new reminder"
          >
            <Plus className="w-8 h-8 stroke-[2.5]" />
          </button>
        </div>

        {/* Completed Tab */}
        <button
          onClick={() => onSelectTab('completed')}
          className={`flex flex-col items-center justify-center flex-1 py-1 relative transition-colors ${
            currentTab === 'completed'
              ? 'text-indigo-400 font-bold'
              : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          {currentTab === 'completed' ? (
            <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full mb-1" />
          ) : (
            <div className="w-1.5 h-1.5 bg-transparent rounded-full mb-1" />
          )}
          <div className="relative">
            <CheckCircle2 className={`w-5 h-5 mb-0.5 ${currentTab === 'completed' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            {completedCount > 0 && (
              <span className="absolute -top-1 -right-2 px-1 min-w-3.5 h-3.5 bg-emerald-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                {completedCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold tracking-tight">Completed</span>
        </button>

        {/* Settings Tab */}
        <button
          onClick={() => onSelectTab('settings')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentTab === 'settings'
              ? 'text-indigo-400 font-bold'
              : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          {currentTab === 'settings' ? (
            <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full mb-1" />
          ) : (
            <div className="w-1.5 h-1.5 bg-transparent rounded-full mb-1" />
          )}
          <Settings className={`w-5 h-5 mb-0.5 ${currentTab === 'settings' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] font-bold tracking-tight">Settings</span>
        </button>
      </div>
    </nav>
  );
};
