import React from 'react';
import { Bell, Clock, CheckCircle2, Volume2, AlarmClockOff, Moon } from 'lucide-react';
import { Reminder } from '../types';
import { reminderEngine } from '../services/reminderEngine';

interface AlarmScreenProps {
  reminder: Reminder | null;
  onDismiss: () => void;
  onSnooze: (minutes: number) => void;
  onComplete: (id: string) => void;
  use24h?: boolean;
}

export const AlarmScreen: React.FC<AlarmScreenProps> = ({
  reminder,
  onDismiss,
  onSnooze,
  onComplete,
  use24h = false,
}) => {
  if (!reminder) return null;

  const formattedTime = reminderEngine.formatDisplayTime(reminder.time, use24h);

  // Parse time and meridiem for split styling
  let timeDigits = formattedTime;
  let meridiem = '';
  if (formattedTime.includes(' ')) {
    const parts = formattedTime.split(' ');
    timeDigits = parts[0];
    meridiem = parts[1];
  }

  const quoteText = reminder.description
    ? `“${reminder.description}”`
    : `“Discipline is choosing between what you want now and what you want most.”`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-4 sm:p-6 select-none overflow-hidden">
      {/* Background Animated Pulse Glows */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-96 h-96 rounded-full bg-indigo-600/15 animate-pulse blur-3xl" />
      </div>

      {/* Sleek Alarm Card */}
      <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 p-6 sm:p-8 w-full max-w-md flex flex-col justify-center items-center text-center relative overflow-hidden shadow-2xl">
        {/* Bell Icon Circle */}
        <div className="relative mb-6">
          <div className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-indigo-500/30 text-white animate-bell-ring">
            <Bell className="w-9 h-9 stroke-[2.5]" />
          </div>
        </div>

        {/* Eyebrow Tracking */}
        <p className="text-xs font-black uppercase tracking-[0.3em] text-indigo-400 mb-2">
          Scheduled Alarm
        </p>

        {/* Task Title */}
        <h2 className="text-3xl sm:text-4xl font-black mb-4 uppercase tracking-tight text-white line-clamp-2">
          {reminder.title}
        </h2>

        {/* Big Thin Time */}
        <div className="text-5xl sm:text-6xl font-thin text-slate-200 mb-6 font-mono tracking-tight flex items-baseline justify-center gap-2">
          <span>{timeDigits}</span>
          {meridiem && (
            <span className="text-xl sm:text-2xl font-bold text-slate-500 font-sans">
              {meridiem}
            </span>
          )}
        </div>

        {/* Quote / Description */}
        <p className="text-slate-400 mb-8 italic text-sm sm:text-base max-w-xs leading-relaxed">
          {quoteText}
        </p>

        {/* Snooze Options */}
        <div className="w-full grid grid-cols-2 gap-3 mb-3">
          <button
            onClick={() => onSnooze(5)}
            className="bg-slate-800 hover:bg-slate-700 active:scale-95 py-3.5 sm:py-4 rounded-2xl font-bold text-xs sm:text-sm border border-slate-700 text-slate-200 transition-all"
          >
            Snooze (5m)
          </button>
          <button
            onClick={() => onSnooze(10)}
            className="bg-slate-800 hover:bg-slate-700 active:scale-95 py-3.5 sm:py-4 rounded-2xl font-bold text-xs sm:text-sm border border-slate-700 text-slate-200 transition-all"
          >
            Snooze (10m)
          </button>
        </div>

        {/* Dismiss Alarm Button */}
        <button
          onClick={onDismiss}
          className="w-full bg-indigo-600 hover:bg-indigo-500 active:scale-95 py-4 sm:py-5 rounded-2xl font-black tracking-widest text-xs sm:text-sm shadow-lg shadow-indigo-900/50 text-white uppercase transition-all mb-2.5 flex items-center justify-center gap-2"
        >
          <AlarmClockOff className="w-4 h-4" />
          <span>Dismiss Alarm</span>
        </button>

        {/* Complete Task Option */}
        <button
          onClick={() => onComplete(reminder.id)}
          className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 py-2 transition-colors flex items-center gap-1.5"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Mark as Completed</span>
        </button>
      </div>
    </div>
  );
};
