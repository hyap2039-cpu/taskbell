import React, { useState } from 'react';
import { CheckCircle2, RotateCcw, Trash2, Sparkles, Calendar, Clock } from 'lucide-react';
import { Reminder, AppSettings } from '../types';
import { ReminderCard } from '../components/ReminderCard';

interface CompletedViewProps {
  completedReminders: Reminder[];
  settings: AppSettings;
  onRestoreReminder: (id: string) => void;
  onDeleteReminder: (reminder: Reminder) => void;
  onEditReminder: (reminder: Reminder) => void;
}

export const CompletedView: React.FC<CompletedViewProps> = ({
  completedReminders,
  settings,
  onRestoreReminder,
  onDeleteReminder,
  onEditReminder,
}) => {
  return (
    <div className="space-y-4 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Completed Tasks
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Archived tasks and completed goals
          </p>
        </div>

        <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400">
          {completedReminders.length} Done
        </span>
      </div>

      {completedReminders.length === 0 ? (
        <div className="py-14 px-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-900/40 text-emerald-400 flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
            No Completed Tasks Yet
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
            When you complete tasks or dismiss one-time alarms, they will appear here with restoration options.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="p-3 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/50 dark:border-emerald-900/40 text-xs text-emerald-800 dark:text-emerald-300 flex items-center justify-between">
            <span>Tap the green restore icon on any task to reschedule it.</span>
          </div>

          {completedReminders.map((reminder) => (
            <ReminderCard
              key={reminder.id}
              reminder={reminder}
              onToggle={() => {}}
              onEdit={onEditReminder}
              onDelete={onDeleteReminder}
              onRestore={onRestoreReminder}
              use24h={settings.twentyFourHourFormat}
            />
          ))}
        </div>
      )}
    </div>
  );
};
