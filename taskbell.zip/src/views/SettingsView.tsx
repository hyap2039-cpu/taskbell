import React, { useState } from 'react';
import { 
  Bell, 
  Volume2, 
  Vibrate, 
  Clock, 
  Smartphone, 
  Moon, 
  Sun, 
  Monitor, 
  Trash2, 
  Info, 
  ShieldCheck, 
  AlertCircle,
  Play, 
  Square,
  Check,
  Zap,
  ExternalLink
} from 'lucide-react';
import { AppSettings, AlarmSoundId } from '../types';
import { notificationService, NotificationPermissionState } from '../services/notificationService';
import { soundService } from '../services/soundService';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (updates: Partial<AppSettings>) => void;
  onClearAllData: () => void;
  onTriggerInstantTest: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onClearAllData,
  onTriggerInstantTest,
}) => {
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermissionState>(
    notificationService.getPermissionStatus()
  );
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [notificationTestSent, setNotificationTestSent] = useState(false);

  const handleRequestPermission = async () => {
    const status = await notificationService.requestPermission();
    setPermissionStatus(status);
  };

  const handleTestNotification = async () => {
    const success = await notificationService.showReminderNotification({
      id: 'test-notification',
      title: 'TaskBell Notification Test',
      description: 'Your browser notifications are configured and working properly!',
      date: '2026-09-04',
      time: '12:00',
      repeat: 'once',
      sound: settings.defaultSound,
      vibration: true,
      notification: true,
      enabled: true,
      completed: false,
      createdAt: new Date().toISOString(),
    });

    if (success) {
      setNotificationTestSent(true);
      setTimeout(() => setNotificationTestSent(false), 3000);
    }
  };

  const handleToggleSoundPreview = (soundId: AlarmSoundId) => {
    if (isPlayingPreview) {
      soundService.stop();
      setIsPlayingPreview(false);
    } else {
      setIsPlayingPreview(true);
      soundService.setVolume(settings.volume);
      soundService.playSinglePattern(soundId);
      setTimeout(() => setIsPlayingPreview(false), 1600);
    }
  };

  const handleVolumeChange = (newVolume: number) => {
    onUpdateSettings({ volume: newVolume });
    soundService.setVolume(newVolume);
  };

  return (
    <div className="space-y-6 pb-28">
      {/* Title */}
      <div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Settings
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Preferences, audio calibration, and Android alarm system info
        </p>
      </div>

      {/* 1. Android Alarm Version Information (Prominently Highlighted) */}
      <section className="rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-900 border border-indigo-900/60 text-white p-5 shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex items-start gap-3 relative z-10">
          <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-500/30">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <span>Android Native Alarm System</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-500/30 text-indigo-200">
                Capacitor Ready
              </span>
            </h3>
            <p className="text-xs text-slate-300 mt-2 font-medium leading-relaxed">
              "For reliable alarms when your phone is locked or the app is running in the background, install the Android version. The Android version uses the native Android alarm system."
            </p>
            <div className="mt-3 pt-3 border-t border-indigo-900/50 text-[11px] text-slate-400 space-y-1">
              <p>
                • <strong>Web Version:</strong> Uses browser timers and AudioContext while app is open/active.
              </p>
              <p>
                • <strong>Native Android:</strong> Connects to Android's native <code className="bg-black/30 px-1 py-0.5 rounded text-indigo-300 font-mono">AlarmManager.setExactAndAllowWhileIdle()</code> to wake your phone even in Doze mode.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Notification Permissions */}
      <section className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                Browser Notifications
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Permission status: <span className="font-semibold capitalize text-slate-700 dark:text-slate-300">{permissionStatus}</span>
              </div>
            </div>
          </div>

          {permissionStatus === 'granted' ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
              <Check className="w-3.5 h-3.5" />
              Enabled
            </span>
          ) : permissionStatus === 'unsupported' ? (
            <span className="text-xs text-amber-600 dark:text-amber-400 font-semibold">
              Not Supported
            </span>
          ) : (
            <button
              onClick={handleRequestPermission}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm transition-all"
            >
              Request Permission
            </button>
          )}
        </div>

        {permissionStatus === 'granted' && (
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400">Test if notifications pop up properly:</span>
            <button
              onClick={handleTestNotification}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {notificationTestSent ? 'Notification Sent!' : 'Send Test Notification'}
            </button>
          </div>
        )}
      </section>

      {/* 3. Audio & Alarm Sound Customization */}
      <section className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Volume2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                Default Alarm Sound
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Built-in offline sound synthesizers
              </div>
            </div>
          </div>
        </div>

        {/* Sound Selection Grid */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'classic', name: 'Classic', desc: 'Twin hammer' },
            { id: 'digital', name: 'Digital', desc: 'Triple beep' },
            { id: 'gentle', name: 'Gentle', desc: 'Harmonic' },
          ].map((s) => (
            <button
              key={s.id}
              onClick={() => {
                onUpdateSettings({ defaultSound: s.id as AlarmSoundId });
                handleToggleSoundPreview(s.id as AlarmSoundId);
              }}
              className={`p-3 rounded-2xl border text-left transition-all ${
                settings.defaultSound === s.id
                  ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-900 dark:text-indigo-100 ring-2 ring-indigo-500/20'
                  : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              <div className="text-xs font-bold flex items-center justify-between">
                <span>{s.name}</span>
                {settings.defaultSound === s.id && <Check className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />}
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{s.desc}</div>
            </button>
          ))}
        </div>

        {/* Volume Slider */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
            <span>Volume Level</span>
            <span className="font-mono">{Math.round(settings.volume * 100)}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={settings.volume}
            onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
            className="w-full accent-indigo-600 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
          />
        </div>

        {/* Vibration Default Setting */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Vibrate className="w-4 h-4 text-slate-500 dark:text-slate-400" />
            <div>
              <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Default Vibration
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400">Vibrate during alarm trigger</div>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.defaultVibration}
              onChange={(e) => onUpdateSettings({ defaultVibration: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-10 h-6 bg-slate-200 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>
      </section>

      {/* 4. Snooze & Clock Preferences */}
      <section className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        {/* Default Snooze Duration */}
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-bold text-slate-900 dark:text-white">
              Default Snooze Duration
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Minutes added when tapping snooze
            </div>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {[5, 10, 15].map((mins) => (
              <button
                key={mins}
                onClick={() => onUpdateSettings({ defaultSnoozeMinutes: mins as 5 | 10 | 15 })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  settings.defaultSnoozeMinutes === mins
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {mins}m
              </button>
            ))}
          </div>
        </div>

        {/* 24-hour time format toggle */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
              24-Hour Clock Format
            </div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400">Display 14:00 instead of 02:00 PM</div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.twentyFourHourFormat}
              onChange={(e) => onUpdateSettings({ twentyFourHourFormat: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-10 h-6 bg-slate-200 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>
      </section>

      {/* 5. Theme Settings */}
      <section className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="text-sm font-bold text-slate-900 dark:text-white">
          Appearance Theme
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'light', label: 'Light', icon: Sun },
            { id: 'dark', label: 'Dark', icon: Moon },
            { id: 'system', label: 'System', icon: Monitor },
          ].map((th) => {
            const Icon = th.icon;
            const isSelected = settings.theme === th.id;
            return (
              <button
                key={th.id}
                onClick={() => onUpdateSettings({ theme: th.id as 'light' | 'dark' | 'system' })}
                className={`py-3 px-2 rounded-2xl border flex flex-col items-center justify-center gap-1.5 transition-all ${
                  isSelected
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-600 dark:text-indigo-400 font-bold'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-xs">{th.label}</span>
              </button>
            );
          })}
        </div>
      </section>

      {/* 6. Quick Test Action */}
      <section className="p-5 rounded-3xl bg-amber-500/10 border border-amber-500/20 text-slate-900 dark:text-white flex items-center justify-between">
        <div>
          <div className="text-sm font-extrabold flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-500 fill-current" />
            <span>Test Alarm Screen</span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Triggers the full-screen alarm immediately to test audio and vibration.
          </p>
        </div>
        <button
          onClick={onTriggerInstantTest}
          className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all shrink-0"
        >
          Launch Test
        </button>
      </section>

      {/* 7. Clear All Data */}
      <section className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-rose-200/60 dark:border-rose-950/60 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-bold text-rose-600 dark:text-rose-400">
              Clear All Reminders
            </div>
            <div className="text-xs text-slate-500">
              Deletes all local tasks and completed history
            </div>
          </div>

          {!showClearConfirm ? (
            <button
              onClick={() => setShowClearConfirm(true)}
              className="px-3 py-1.5 rounded-xl border border-rose-300 dark:border-rose-800 text-rose-600 text-xs font-bold hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
            >
              Clear Data
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-2.5 py-1 text-xs text-slate-500 hover:underline"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onClearAllData();
                  setShowClearConfirm(false);
                }}
                className="px-3 py-1 rounded-xl bg-rose-600 text-white text-xs font-bold"
              >
                Confirm Delete
              </button>
            </div>
          )}
        </div>
      </section>

      {/* 8. About TaskBell Card */}
      <section className="p-5 rounded-3xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-center space-y-1">
        <div className="text-sm font-extrabold text-slate-900 dark:text-white">
          TaskBell v1.0.0
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Smart Task Alarm Web App • Offline-First • Capacitor & Android Ready
        </p>
        <p className="text-[11px] text-slate-400 dark:text-slate-500 pt-1">
          Zero external database tracking. All data is kept 100% private and on-device.
        </p>
      </section>
    </div>
  );
};
