import React, { useState, useMemo } from 'react';
import { Search, Plus, Filter, Bell, BellOff, Clock, Sparkles } from 'lucide-react';
import { Reminder, AppSettings } from '../types';
import { ReminderCard } from '../components/ReminderCard';

interface ReminderListViewProps {
  reminders: Reminder[];
  settings: AppSettings;
  onOpenAddModal: () => void;
  onEditReminder: (reminder: Reminder) => void;
  onDeleteReminder: (reminder: Reminder) => void;
  onToggleReminder: (id: string) => void;
  onCompleteReminder: (id: string) => void;
  onTriggerNow: (reminder: Reminder) => void;
}

type FilterStatus = 'all' | 'active' | 'paused' | 'snoozed';

export const ReminderListView: React.FC<ReminderListViewProps> = ({
  reminders,
  settings,
  onOpenAddModal,
  onEditReminder,
  onDeleteReminder,
  onToggleReminder,
  onCompleteReminder,
  onTriggerNow,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<FilterStatus>('all');

  // Filter and sort reminders in chronological order
  const filteredReminders = useMemo(() => {
    return reminders
      .filter((r) => !r.completed)
      .filter((r) => {
        // Status filter
        if (filterStatus === 'active' && !r.enabled) return false;
        if (filterStatus === 'paused' && r.enabled) return false;
        if (filterStatus === 'snoozed' && !r.isSnoozed) return false;

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = r.title.toLowerCase().includes(q);
          const matchDesc = r.description?.toLowerCase().includes(q);
          return matchTitle || matchDesc;
        }
        return true;
      })
      .sort((a, b) => {
        // Chronological order by date and time
        const dtA = `${a.date}T${a.time}`;
        const dtB = `${b.date}T${b.time}`;
        return dtA.localeCompare(dtB);
      });
  }, [reminders, filterStatus, searchQuery]);

  const activeCount = reminders.filter((r) => !r.completed && r.enabled).length;
  const pausedCount = reminders.filter((r) => !r.completed && !r.enabled).length;
  const snoozedCount = reminders.filter((r) => !r.completed && r.isSnoozed).length;

  return (
    <div className="space-y-4 pb-24">
      {/* Header with Title & Action */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            All Reminders
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Chronological task schedule and alarm states
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-bold shadow-md shadow-indigo-900/50 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Task</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search task by title or note..."
          className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            Clear
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {[
          { id: 'all', label: 'All', count: reminders.filter((r) => !r.completed).length },
          { id: 'active', label: 'Active', count: activeCount },
          { id: 'paused', label: 'Paused', count: pausedCount },
          { id: 'snoozed', label: 'Snoozed', count: snoozedCount },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterStatus(tab.id as FilterStatus)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              filterStatus === tab.id
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-900/50'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                filterStatus === tab.id
                  ? 'bg-white/20 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Reminders List */}
      {filteredReminders.length === 0 ? (
        <div className="py-12 px-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-3">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
            No Reminders Found
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto mb-4">
            {searchQuery
              ? `No reminders matching "${searchQuery}".`
              : 'You have no tasks matching this filter.'}
          </p>
          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-900/50 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Create Reminder</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredReminders.map((reminder) => (
            <ReminderCard
              key={reminder.id}
              reminder={reminder}
              onToggle={onToggleReminder}
              onEdit={onEditReminder}
              onDelete={onDeleteReminder}
              onComplete={onCompleteReminder}
              onTriggerNow={onTriggerNow}
              use24h={settings.twentyFourHourFormat}
            />
          ))}
        </div>
      )}
    </div>
  );
};
