import React from 'react';
import { 
  Calendar, 
  Clock, 
  Plus, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  ListTodo, 
  Flame,
  Zap,
  Timer
} from 'lucide-react';
import { Reminder, AppSettings } from '../types';
import { NextReminderCard } from '../components/NextReminderCard';
import { ReminderCard } from '../components/ReminderCard';
import { reminderEngine } from '../services/reminderEngine';

interface DashboardViewProps {
  reminders: Reminder[];
  todaysReminders: Reminder[];
  upcomingReminders: Reminder[];
  completedReminders: Reminder[];
  nextReminderData: { reminder: Reminder; triggerDate: Date } | null;
  currentTime: Date;
  settings: AppSettings;
  onOpenAddModal: () => void;
  onEditReminder: (reminder: Reminder) => void;
  onDeleteReminder: (reminder: Reminder) => void;
  onToggleReminder: (id: string) => void;
  onCompleteReminder: (id: string) => void;
  onTriggerNow: (reminder: Reminder) => void;
  onGoToCompleted: () => void;
  onGoToReminders: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  reminders,
  todaysReminders,
  upcomingReminders,
  completedReminders,
  nextReminderData,
  currentTime,
  settings,
  onOpenAddModal,
  onEditReminder,
  onDeleteReminder,
  onToggleReminder,
  onCompleteReminder,
  onTriggerNow,
  onGoToCompleted,
  onGoToReminders,
}) => {
  const formattedTime = currentTime.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: !settings.twentyFourHourFormat,
  });

  const formattedDate = currentTime.toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  // Handle instant 10-second test alarm
  const handleTrigger10sTest = () => {
    const testTime = new Date(Date.now() + 10 * 1000);
    const h = String(testTime.getHours()).padStart(2, '0');
    const m = String(testTime.getMinutes()).padStart(2, '0');
    const s = String(testTime.getSeconds()).padStart(2, '0');
    const y = testTime.getFullYear();
    const month = String(testTime.getMonth() + 1).padStart(2, '0');
    const d = String(testTime.getDate()).padStart(2, '0');

    const testReminder: Reminder = {
      id: `quick-test-${Date.now()}`,
      title: 'Gym jaana hai (Quick Test)',
      description: 'Scheduled test alarm triggering right now to verify sound and screen!',
      date: `${y}-${month}-${d}`,
      time: `${h}:${m}`,
      repeat: 'once',
      sound: settings.defaultSound || 'classic',
      vibration: true,
      notification: true,
      enabled: true,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    // Fire test alarm
    onTriggerNow(testReminder);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Current Time & Date Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-950/60 border border-indigo-800/40 text-indigo-400 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold font-mono tracking-tight text-white">
              {formattedTime}
            </div>
            <div className="text-xs text-slate-400 font-medium">
              {formattedDate}
            </div>
          </div>
        </div>

        {/* Quick Test Alarm button */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleTrigger10sTest}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-indigo-300 border border-slate-700 hover:border-indigo-500/40 text-xs font-bold active:scale-95 transition-all"
            title="Fire an instant alarm test"
          >
            <Zap className="w-3.5 h-3.5 fill-current text-indigo-400" />
            <span>Instant Alarm Test</span>
          </button>
        </div>
      </div>

      {/* 1. "Next Reminder" Card */}
      <section>
        <NextReminderCard
          nextData={nextReminderData}
          onOpenAddModal={onOpenAddModal}
          onEditReminder={onEditReminder}
          onTriggerNow={onTriggerNow}
          use24h={settings.twentyFourHourFormat}
        />
      </section>

      {/* 2. Today's Tasks Section */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">
            Today's Schedule
          </h3>

          <button
            onClick={onGoToReminders}
            className="text-xs font-semibold text-indigo-400 hover:underline flex items-center gap-1"
          >
            <span>See all</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {todaysReminders.length === 0 ? (
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
            <p className="text-xs text-slate-400">
              No tasks scheduled for today. Tap the <strong className="text-indigo-400">+</strong> button to create one!
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {todaysReminders.map((reminder) => (
              <ReminderCard
                key={reminder.id}
                reminder={reminder}
                onToggle={onToggleReminder}
                onEdit={onEditReminder}
                onDelete={onDeleteReminder}
                onComplete={onCompleteReminder}
                onTriggerNow={onTriggerNow}
                use24h={settings.twentyFourHourFormat}
              />
            ))}
          </div>
        )}
      </section>

      {/* 3. Upcoming Reminders Section */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">
            Upcoming Reminders
          </h3>
          <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-slate-800 text-slate-400 border border-slate-700">
            {upcomingReminders.length}
          </span>
        </div>

        {upcomingReminders.length === 0 ? (
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400">
            No upcoming reminders for future dates.
          </div>
        ) : (
          <div className="space-y-2.5">
            {upcomingReminders.slice(0, 3).map((reminder) => (
              <ReminderCard
                key={reminder.id}
                reminder={reminder}
                onToggle={onToggleReminder}
                onEdit={onEditReminder}
                onDelete={onDeleteReminder}
                onComplete={onCompleteReminder}
                onTriggerNow={onTriggerNow}
                use24h={settings.twentyFourHourFormat}
              />
            ))}
            {upcomingReminders.length > 3 && (
              <button
                onClick={onGoToReminders}
                className="w-full py-2 text-center text-xs font-semibold text-indigo-400 hover:underline"
              >
                +{upcomingReminders.length - 3} more upcoming reminders
              </button>
            )}
          </div>
        )}
      </section>

      {/* 4. Completed Tasks Summary Card */}
      {completedReminders.length > 0 && (
        <section>
          <div
            onClick={onGoToCompleted}
            className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between cursor-pointer hover:border-slate-700 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold text-white">
                  {completedReminders.length} Completed Task{completedReminders.length > 1 ? 's' : ''}
                </div>
                <div className="text-xs text-slate-400">
                  Tap to view task history or restore items
                </div>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </div>
        </section>
      )}

      {/* 5. Capacitor & Architecture Badge Card */}
      <section>
        <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 flex flex-col justify-between relative overflow-hidden shadow-lg">
          <div className="mb-4">
            <span className="px-3 py-1 bg-indigo-900/30 text-indigo-400 text-[10px] rounded-full font-bold border border-indigo-800/50 mb-3 inline-block">
              Capacitor Ready
            </span>
            <h4 className="text-lg font-black text-white mb-1">Architecture</h4>
            <p className="text-slate-400 text-xs leading-relaxed">
              Built with clean separation between the React UI layer and the native AlarmManager scheduler interface.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <span className="px-3 py-1 bg-slate-800 text-slate-400 text-[10px] rounded-full font-bold border border-slate-700">No Backend</span>
            <span className="px-3 py-1 bg-slate-800 text-slate-400 text-[10px] rounded-full font-bold border border-slate-700">Local Storage</span>
            <span className="px-3 py-1 bg-slate-800 text-slate-400 text-[10px] rounded-full font-bold border border-slate-700">Audio Synth</span>
          </div>
        </div>
      </section>
    </div>
  );
};
