import React, { useState } from 'react';
import { NavigationTab, Reminder } from './types';
import { useReminders } from './hooks/useReminders';
import { Header } from './components/Header';
import { BottomNavigation } from './components/BottomNavigation';
import { AddEditReminderModal } from './components/AddEditReminderModal';
import { AlarmScreen } from './components/AlarmScreen';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { DashboardView } from './views/DashboardView';
import { ReminderListView } from './views/ReminderListView';
import { CompletedView } from './views/CompletedView';
import { SettingsView } from './views/SettingsView';
import { reminderEngine } from './services/reminderEngine';

export default function App() {
  const {
    reminders,
    todaysReminders,
    upcomingReminders,
    completedReminders,
    nextReminderData,
    settings,
    activeAlarm,
    currentTime,
    addReminder,
    updateReminder,
    deleteReminder,
    toggleReminder,
    completeReminder,
    restoreReminder,
    snoozeActiveAlarm,
    dismissActiveAlarm,
    updateSettings,
    clearAllData,
  } = useReminders();

  const [currentTab, setCurrentTab] = useState<NavigationTab>('home');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);
  const [deletingReminder, setDeletingReminder] = useState<Reminder | null>(null);

  // Handlers for Add/Edit
  const handleOpenAddModal = () => {
    setEditingReminder(null);
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (reminder: Reminder) => {
    setEditingReminder(reminder);
    setIsAddModalOpen(true);
  };

  const handleSaveReminder = (reminder: Reminder) => {
    if (editingReminder) {
      updateReminder(reminder.id, reminder);
    } else {
      addReminder(reminder);
    }
  };

  // Handlers for Delete Confirmation
  const handleRequestDelete = (reminder: Reminder) => {
    setDeletingReminder(reminder);
  };

  const handleConfirmDelete = () => {
    if (deletingReminder) {
      deleteReminder(deletingReminder.id);
      setDeletingReminder(null);
    }
  };

  // Immediate test alarm trigger
  const handleTriggerInstantAlarm = (reminder?: Reminder) => {
    const target = reminder || {
      id: `instant-test-${Date.now()}`,
      title: 'Gym jaana hai',
      description: 'Time to complete your workout session!',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
      repeat: 'daily',
      sound: settings.defaultSound || 'classic',
      vibration: true,
      notification: true,
      enabled: true,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    reminderEngine.handleReminderTriggered(target);
  };

  const activeCount = reminders.filter((r) => !r.completed && r.enabled).length;
  const completedCount = completedReminders.length;

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col items-center selection:bg-blue-500 selection:text-white">
      {/* Mobile-centric container: Max width for clean phone/tablet view, centered on desktop */}
      <div className="w-full max-w-xl min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 shadow-2xl relative">
        {/* Sticky App Header */}
        <Header
          settings={settings}
          onUpdateSettings={updateSettings}
          currentTime={currentTime}
          activeCount={activeCount}
        />

        {/* Main Content Area */}
        <main className="flex-1 px-4 pt-4 pb-6 overflow-y-auto">
          {currentTab === 'home' && (
            <DashboardView
              reminders={reminders}
              todaysReminders={todaysReminders}
              upcomingReminders={upcomingReminders}
              completedReminders={completedReminders}
              nextReminderData={nextReminderData}
              currentTime={currentTime}
              settings={settings}
              onOpenAddModal={handleOpenAddModal}
              onEditReminder={handleOpenEditModal}
              onDeleteReminder={handleRequestDelete}
              onToggleReminder={toggleReminder}
              onCompleteReminder={completeReminder}
              onTriggerNow={handleTriggerInstantAlarm}
              onGoToCompleted={() => setCurrentTab('completed')}
              onGoToReminders={() => setCurrentTab('reminders')}
            />
          )}

          {currentTab === 'reminders' && (
            <ReminderListView
              reminders={reminders}
              settings={settings}
              onOpenAddModal={handleOpenAddModal}
              onEditReminder={handleOpenEditModal}
              onDeleteReminder={handleRequestDelete}
              onToggleReminder={toggleReminder}
              onCompleteReminder={completeReminder}
              onTriggerNow={handleTriggerInstantAlarm}
            />
          )}

          {currentTab === 'completed' && (
            <CompletedView
              completedReminders={completedReminders}
              settings={settings}
              onRestoreReminder={restoreReminder}
              onDeleteReminder={handleRequestDelete}
              onEditReminder={handleOpenEditModal}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={updateSettings}
              onClearAllData={clearAllData}
              onTriggerInstantTest={() => handleTriggerInstantAlarm()}
            />
          )}
        </main>

        {/* Bottom Navigation */}
        <BottomNavigation
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          onOpenAddModal={handleOpenAddModal}
          activeCount={activeCount}
          completedCount={completedCount}
        />

        {/* Dedicated Add / Edit Reminder Modal */}
        <AddEditReminderModal
          isOpen={isAddModalOpen}
          onClose={() => {
            setIsAddModalOpen(false);
            setEditingReminder(null);
          }}
          onSave={handleSaveReminder}
          initialReminder={editingReminder}
          settings={settings}
        />

        {/* Delete Confirmation Modal */}
        <DeleteConfirmModal
          isOpen={deletingReminder !== null}
          reminder={deletingReminder}
          onConfirm={handleConfirmDelete}
          onCancel={() => setDeletingReminder(null)}
        />

        {/* Full-Screen Alarm Screen (Appears when active alarm is ringing) */}
        {activeAlarm && (
          <AlarmScreen
            reminder={activeAlarm}
            onDismiss={dismissActiveAlarm}
            onSnooze={snoozeActiveAlarm}
            onComplete={completeReminder}
            use24h={settings.twentyFourHourFormat}
          />
        )}
      </div>
    </div>
  );
}
