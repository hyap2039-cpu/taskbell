import { registerPlugin, Capacitor } from '@capacitor/core';
import type { Reminder } from '../types';

export interface NativeAlarmPlugin {
  schedule(options: {
    id: string;
    triggerAtMillis: number;
    title: string;
    description?: string;
    sound: string;
    vibration: boolean;
    notification: boolean;
    repeat: string;
    weekday?: number;
  }): Promise<{ scheduled: boolean; exactAlarmPermission: boolean }>;
  cancel(options: { id: string }): Promise<void>;
  cancelAll(): Promise<void>;
  requestExactAlarmPermission(): Promise<{ granted: boolean }>;
  requestNotificationPermission(): Promise<{ granted: boolean }>;
  stopAlarm(): Promise<void>;
}

const NativeAlarm = registerPlugin<NativeAlarmPlugin>('TaskBellAlarm');

export function isNativeAlarmAvailable(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
}

export async function scheduleNativeAlarm(reminder: Reminder, triggerAt: Date) {
  if (!isNativeAlarmAvailable()) return null;
  return NativeAlarm.schedule({
    id: reminder.id,
    triggerAtMillis: triggerAt.getTime(),
    title: reminder.title,
    description: reminder.description,
    sound: reminder.sound,
    vibration: reminder.vibration,
    notification: reminder.notification,
    repeat: reminder.repeat,
    weekday: reminder.weekday,
  });
}

export async function cancelNativeAlarm(id: string) {
  if (!isNativeAlarmAvailable()) return;
  await NativeAlarm.cancel({ id });
}

export async function requestNativeAlarmPermission() {
  if (!isNativeAlarmAvailable()) return { granted: true };
  return NativeAlarm.requestExactAlarmPermission();
}

export async function requestNativeNotificationPermission() {
  if (!isNativeAlarmAvailable()) return { granted: true };
  return NativeAlarm.requestNotificationPermission();
}

export async function stopNativeAlarm() {
  if (!isNativeAlarmAvailable()) return;
  await NativeAlarm.stopAlarm();
}
