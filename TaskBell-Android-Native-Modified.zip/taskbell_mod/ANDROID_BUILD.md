# TaskBell Android build

This project is now Capacitor-ready and contains the native alarm source template.

1. Install dependencies: `npm install`
2. Build web app: `npm run build`
3. Add Android platform: `npx cap add android`
4. Sync: `npx cap sync android`
5. Copy `android-template/app/src/main/java/com/taskbell/app/*.java` into the generated Android app package.
6. Merge `android-template/AndroidManifest-snippet.xml` entries into `android/app/src/main/AndroidManifest.xml`.
7. Register the custom plugin in the generated `MainActivity`/Capacitor app as required by the Capacitor version.
8. Build with Android Studio/Gradle.

The web app remains fully usable as a PWA/browser app. On Android, the scheduler automatically switches to the native plugin when running inside Capacitor.

Exact alarms require Android's “Alarms & reminders” special access on supported versions. Notification permission is also requested on Android 13+.
