package com.taskbell.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class AlarmActivity extends Activity {
    private static MediaPlayer player;
    private static AlarmActivity current;
    private int notificationId;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        current = this;
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK |
                PowerManager.ACQUIRE_CAUSES_WAKEUP, "TaskBell:AlarmWake");
        wl.acquire(5000);

        String title = getIntent().getStringExtra("title");
        notificationId = getIntent().getStringExtra("id").hashCode();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(48, 80, 48, 48);
        root.setGravity(android.view.Gravity.CENTER);
        TextView heading = new TextView(this); heading.setText("⏰ TaskBell"); heading.setTextSize(32); heading.setTextColor(Color.WHITE);
        TextView task = new TextView(this); task.setText(title == null ? "Task reminder" : title); task.setTextSize(28); task.setTextColor(Color.WHITE); task.setPadding(0, 40, 0, 40);
        Button stop = new Button(this); stop.setText("STOP ALARM"); stop.setOnClickListener(v -> stopCurrentAlarm());
        root.setBackgroundColor(Color.rgb(15,23,42)); root.addView(heading); root.addView(task); root.addView(stop);
        setContentView(root);
        startAlarmSound();
    }

    private void startAlarmSound() {
        try {
            stopPlayer();
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            player = MediaPlayer.create(this, uri);
            if (player != null) { player.setLooping(true); player.start(); }
        } catch (Exception ignored) {}
    }

    public static void stopCurrentAlarm() {
        stopPlayer();
        if (current != null) { current.dismissNotification(); current.finishAndRemoveTask(); current = null; }
    }

    private void dismissNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(notificationId);
    }

    private static void stopPlayer() {
        if (player != null) { try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {} player.release(); player = null; }
    }

    @Override protected void onDestroy() { if (current == this) current = null; super.onDestroy(); }
}
