package com.taskbell.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "TaskBellAlarm")
public class TaskBellAlarmPlugin extends Plugin {
    private static final int NOTIFICATION_PERMISSION_REQUEST = 4101;

    @PluginMethod
    public void schedule(PluginCall call) {
        String id = call.getString("id");
        long triggerAt = call.getLong("triggerAtMillis", 0L);
        String title = call.getString("title", "Task Reminder");
        String description = call.getString("description", "");
        String sound = call.getString("sound", "classic");
        boolean vibration = call.getBoolean("vibration", true);
        boolean notification = call.getBoolean("notification", true);
        String repeat = call.getString("repeat", "once");
        Integer weekday = call.getInt("weekday");

        if (id == null || triggerAt <= 0) {
            call.reject("Invalid alarm data");
            return;
        }

        AlarmScheduler.schedule(getContext(), id, triggerAt, title, description, sound,
                vibration, notification, repeat, weekday);

        JSObject ret = new JSObject();
        ret.put("scheduled", true);
        ret.put("exactAlarmPermission", canScheduleExactAlarms());
        call.resolve(ret);
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        String id = call.getString("id");
        if (id != null) AlarmScheduler.cancel(getContext(), id);
        call.resolve();
    }

    @PluginMethod
    public void cancelAll(PluginCall call) {
        AlarmScheduler.cancelAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void requestExactAlarmPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getContext().getPackageName()));
                getActivity().startActivity(intent);
            }
            JSObject ret = new JSObject();
            ret.put("granted", am.canScheduleExactAlarms());
            call.resolve(ret);
        } else {
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
            JSObject ret = new JSObject(); ret.put("granted", false); call.resolve(ret);
        } else {
            JSObject ret = new JSObject(); ret.put("granted", true); call.resolve(ret);
        }
    }

    @PluginMethod
    public void stopAlarm(PluginCall call) {
        AlarmActivity.stopCurrentAlarm();
        call.resolve();
    }

    private boolean canScheduleExactAlarms() {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
        return am.canScheduleExactAlarms();
    }
}
