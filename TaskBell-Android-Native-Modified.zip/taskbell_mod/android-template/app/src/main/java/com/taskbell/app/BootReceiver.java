package com.taskbell.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Placeholder boot receiver. The web layer re-schedules all persisted reminders
 * when the app is opened; production builds can extend this to persist native
 * reminder payloads in SharedPreferences and restore them here. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        // Intentionally lightweight. See README for persistence extension.
    }
}
