package com.taskbell.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "taskbell_alarm";

    @Override public void onReceive(Context context, Intent intent) {
        if (!"com.taskbell.app.ALARM".equals(intent.getAction())) return;

        createChannel(context);
        Intent alarmIntent = new Intent(context, AlarmActivity.class)
                .putExtras(intent)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullScreen = PendingIntent.getActivity(context,
                intent.getIntExtra("id", "".hashCode()), alarmIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(intent.getStringExtra("title"))
                .setContentText("TaskBell reminder")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setOngoing(true)
                .setAutoCancel(false)
                .setFullScreenIntent(fullScreen, true);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(intent.getStringExtra("id").hashCode(), builder.build());

        // A once alarm is consumed here. Recurring alarms are rescheduled by the
        // React layer after the app resumes; boot receiver restores saved alarms.
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        Uri alarm = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "TaskBell Alarms",
                NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("TaskBell alarm notifications");
        channel.setSound(alarm, attrs);
        channel.enableVibration(true);
        nm.createNotificationChannel(channel);
    }
}
