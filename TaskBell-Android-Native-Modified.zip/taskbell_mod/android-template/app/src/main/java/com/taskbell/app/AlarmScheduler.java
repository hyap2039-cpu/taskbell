package com.taskbell.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class AlarmScheduler {
    private static final Map<String, PendingIntent> PENDING = new ConcurrentHashMap<>();

    private AlarmScheduler() {}

    public static void schedule(Context context, String id, long triggerAtMillis,
                                 String title, String description, String sound,
                                 boolean vibration, boolean notification, String repeat,
                                 Integer weekday) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class)
                .setAction("com.taskbell.app.ALARM")
                .putExtra("id", id)
                .putExtra("title", title)
                .putExtra("description", description)
                .putExtra("sound", sound)
                .putExtra("vibration", vibration)
                .putExtra("notification", notification)
                .putExtra("repeat", repeat)
                .putExtra("weekday", weekday == null ? -1 : weekday);

        PendingIntent pi = PendingIntent.getBroadcast(context, stableRequestCode(id), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PENDING.put(id, pi);

        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            throw new SecurityException("Alarms & reminders permission is not granted");
        }

        if (Build.VERSION.SDK_INT >= 23) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        }
    }

    public static void cancel(Context context, String id) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class).setAction("com.taskbell.app.ALARM");
        PendingIntent pi = PendingIntent.getBroadcast(context, stableRequestCode(id), intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) { alarmManager.cancel(pi); pi.cancel(); }
        PENDING.remove(id);
    }

    public static void cancelAll(Context context) {
        for (String id : PENDING.keySet()) cancel(context, id);
    }

    private static int stableRequestCode(String id) { return id.hashCode() & 0x7fffffff; }
}
