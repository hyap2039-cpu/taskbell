// Add this to the generated Capacitor MainActivity.
// Keep the package declaration from your generated MainActivity.

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(com.taskbell.app.TaskBellAlarmPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
