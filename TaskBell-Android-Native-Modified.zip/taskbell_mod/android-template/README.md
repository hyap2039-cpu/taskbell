# TaskBell Android native alarm layer

This is the Android-native alarm layer for the TaskBell web app. It is intentionally
kept separate from the existing browser scheduler: browsers continue to use the
PWA/web timer, while the Android build uses `AlarmManager` through the
`TaskBellAlarm` Capacitor plugin.

## Build setup

```bash
npm install
npm run build
npx cap add android
npx cap sync android
```

Then copy the Java files in this folder into the generated Android package and
merge `AndroidManifest-snippet.xml`. Replace the generated `MainActivity` with the
pattern in `MainActivity-snippet.java`, preserving its package name.

The native layer uses exact wake-up alarms, a high-priority alarm notification and
an alarm activity that can appear over the lock screen and turn the display on.
Android 12+ requires the user-facing "Alarms & reminders" special access for exact
alarms in this implementation.

This package is source-complete for the native layer but is not a precompiled APK;
Android SDK/Gradle must compile the generated Capacitor `android/` project.
